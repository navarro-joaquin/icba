<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PagoRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'alumno_id' => 'required|exists:alumnos,id',
            'inscripcion_id' => 'required|exists:inscripciones,id',
            'fecha_pago' => 'required|date',
            'monto' => 'required|numeric',
            'descripcion' => 'nullable'
        ];
    }

    public function attributes()
    {
        return [
            'alumno_id' => 'Alumno',
            'inscripcion_id' => 'Inscripción',
            'fecha_pago' => 'Fecha de pago',
            'monto' => 'Monto',
            'descripcion' => 'Descripción'
        ];
    }

    public function messages()
    {
        return [
            'required' => 'El campo :attribute es obligatorio',
            'exists' => 'El campo :attribute seleccionado no existe',
            'date' => 'El campo :attribute debe ser una fecha válida',
            'numeric' => 'El campo :attribute debe ser un número'
        ];
    }
}
