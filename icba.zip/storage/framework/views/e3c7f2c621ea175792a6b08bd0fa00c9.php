<a href="<?php echo e(route('usuarios.edit', $user)); ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>

<button class="btn btn-sm <?php if($user->status == 'active'): ?> btn-danger <?php else: ?> btn-success <?php endif; ?> btn-delete" data-id="<?php echo e($user->id); ?>" data-estado="<?php echo e($user->status); ?>">
    <i class="fas <?php if($user->status == 'active'): ?> fa-ban <?php else: ?> fa-eye <?php endif; ?>"></i>
</button><?php /**PATH C:\Users\anavarro\source\repos\icba\resources\views/usuarios/partials/_actions.blade.php ENDPATH**/ ?>