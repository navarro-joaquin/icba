<a href="<?php echo e(route('alumnos.edit', $alumno)); ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>

<button class="btn btn-sm <?php if($alumno->estado == 'activo'): ?> btn-danger <?php else: ?> btn-success <?php endif; ?> btn-delete" data-id="<?php echo e($alumno->id); ?>" data-estado="<?php echo e($alumno->estado); ?>">
    <i class="fas <?php if($alumno->estado == 'activo'): ?> fa-ban <?php else: ?> fa-check <?php endif; ?>"></i>
</button><?php /**PATH C:\Users\anavarro\source\repos\icba\resources\views/alumnos/partials/_actions.blade.php ENDPATH**/ ?>