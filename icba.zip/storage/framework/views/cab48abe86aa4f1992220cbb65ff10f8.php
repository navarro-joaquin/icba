<a href="<?php echo e(route('cursos-profesores.edit', $curso_profesor)); ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>

<button class="btn btn-sm <?php if($curso_profesor->estado == 'activo'): ?> btn-danger <?php else: ?> btn-success <?php endif; ?> btn-delete" data-id="<?php echo e($curso_profesor->id); ?>" data-estado="<?php echo e($curso_profesor->estado); ?>">
    <i class="fas <?php if($curso_profesor->estado == 'activo'): ?> fa-ban <?php else: ?> fa-check <?php endif; ?>"></i>
</button><?php /**PATH C:\Users\anavarro\source\repos\icba\resources\views/cursos-profesores/partials/_actions.blade.php ENDPATH**/ ?>