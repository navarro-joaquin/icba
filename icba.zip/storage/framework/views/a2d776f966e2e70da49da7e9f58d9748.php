<?php echo csrf_field(); ?>
<?php if(isset($curso_profesor)): ?>
    <?php echo method_field('PUT'); ?>
<?php endif; ?>

<div class="mb-3">
    <label for="curso_gestion_id">Curso y Gestión:</label>
    <select name="curso_gestion_id" id="curso_gestion_id" class="form-control">
        <?php $__empty_1 = true; $__currentLoopData = $cursosGestiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cursoGestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($cursoGestion->id); ?>" <?php echo e(old('curso_gestion_id', $curso_profesor->curso_gestion_id ?? '') == $cursoGestion->id ? 'selected' : ''); ?>>
                <?php echo e($cursoGestion->nombre); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <option value="">No hay cursos disponibles</option>
        <?php endif; ?>
    </select>
</div>

<div class="mb-3">
    <label for="profesor_id">Profesor:</label>
    <select name="profesor_id" id="profesor_id" class="form-control">
        <?php $__empty_1 = true; $__currentLoopData = $profesores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profesor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($profesor->id); ?>" <?php echo e(old('profesor_id', $curso_profesor->profesor_id ?? '') == $profesor->id ? 'selected' : ''); ?>>
                <?php echo e($profesor->nombre); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <option value="">No hay profesores disponibles</option>
        <?php endif; ?>
    </select>
</div>

<button type="submit" class="btn btn-primary">
    <i class="fas fa-save"></i> <?php echo e(isset($alumno) ? 'Actualizar' : 'Registrar'); ?>

</button>
<a href="<?php echo e(route('alumnos.index')); ?>" class="btn btn-info">
    <i class="fas fa-arrow-left"></i> Volver
</a><?php /**PATH C:\Users\anavarro\source\repos\icba\resources\views/cursos-profesores/partials/_form.blade.php ENDPATH**/ ?>