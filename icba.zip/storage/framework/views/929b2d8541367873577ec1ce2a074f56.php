<?php echo csrf_field(); ?>
<?php if(isset($pago)): ?>
    <?php echo method_field('PUT'); ?>
<?php endif; ?>

<div class="mb-3">
    <label for="alumno_id">Alumno</label>
    <select name="alumno_id" class="form-control" id="alumno_id">
        <?php $__empty_1 = true; $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($alumno->id); ?>" <?php echo e(old('alumno_id', $pago->alumno_id ?? '') == $alumno->id ? 'selected' : ''); ?>>
                <?php echo e($alumno->nombre); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <option value="">No hay alumnos registrados</option>
        <?php endif; ?>
    </select>
</div>

<div class="mb-3">
    <label for="inscripcion_id">Inscripción</label>
    <select name="inscripcion_id" class="form-control" id="inscripcion_id">
        <?php $__empty_1 = true; $__currentLoopData = $inscripciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inscripcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($inscripcion->id); ?>" <?php echo e(old('inscripcion_id', $pago->inscripcion_id ?? '') == $inscripcion->id ? 'selected' : ''); ?>>
                <?php echo e($inscripcion->curso_gestion->nombre); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <option value="">No hay inscripiciones registradas</option>
        <?php endif; ?>
    </select>
</div>

<div class="mb-3">
    <label for="fecha_pago">Fecha de Pago</label>
    <input type="date" name="fecha_pago" id="fecha_pago" class="form-control" value="<?php echo e(old('fecha_pago', $pago->fecha_pago ?? '')); ?>">
</div>

<div class="mb-3">
    <label for="monto">Monto (Bs.)</label>
    <input type="number" name="monto" id="monto" class="form-control" value="<?php echo e(old('monto', $pago->monto ?? '')); ?>">
</div>

<div class="mb-3">
    <label for="descripcion">Descripción</label>
    <input type="text" name="descripcion" id="descripcion" class="form-control" value="<?php echo e(old('descripcion', $pago->descripcion ?? '')); ?>">
</div>

<button type="submit" class="btn btn-primary">
    <i class="fas fa-save"></i> <?php echo e(isset($pago) ? 'Actualizar' : 'Registrar'); ?>

</button>
<a href="<?php echo e(route('pagos.index')); ?>" class="btn btn-info">
    <i class="fas fa-arrow-left"></i> Volver
</a>
<?php /**PATH C:\Users\anavarro\source\repos\icba\resources\views/pagos/partials/_form.blade.php ENDPATH**/ ?>