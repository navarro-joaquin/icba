<?php echo csrf_field(); ?>

<?php if(isset($user)): ?>
    <?php echo method_field('PUT'); ?>
<?php endif; ?>

<div class="mb-3">
    <label for="username">Nombre de Usuario</label>
    <input type="text" name="username" id="username" class="form-control" value="<?php echo e(old('username', $user->username ?? '')); ?>">
</div>

<div class="mb-3">
    <label for="email">Email</label>
    <input type="email" name="email" id="email" class="form-control" value="<?php echo e(old('email', $user->email?? '')); ?>">
</div>

<div class="mb-3">
    <label for="role">Rol</label>
    <select name="role" class="form-control" id="role">
        <option value="admin" <?php echo e(old('role', $user->role?? '') == 'admin' ? 'selected' : ''); ?>>Administrador</option>
        <option value="alumno" <?php echo e(old('role', $user->role?? '') == 'alumno' ? 'selected' : ''); ?>>Alumno</option>
        <option value="profesor" <?php echo e(old('role', $user->role?? '') == 'profesor' ? 'selected' : ''); ?>>Profesor</option>
        <option value="gestor" <?php echo e(old('role', $user->role?? '') == 'gestor' ? 'selected' : ''); ?>>Gestor</option>
    </select>
</div>

<div class="mb-3">
    <label for="password">Contraseña</label>
    <input type="password" name="password" id="password" class="form-control">
</div>

<button type="submit" class="btn btn-primary">
    <i class="fas fa-save"></i> <?php echo e(isset($user) ? 'Actualizar' : 'Registrar'); ?>

</button>
<a href="<?php echo e(route('usuarios.index')); ?>" class="btn btn-info">
    <i class="fas fa-arrow-left"></i> Volver
</a>
<?php /**PATH C:\Users\anavarro\source\repos\icba\resources\views/usuarios/partials/_form.blade.php ENDPATH**/ ?>