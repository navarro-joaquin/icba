<a href="<?php echo e(route('gestiones.edit', $gestion)); ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>

<button class="btn btn-sm <?php if($gestion->estado == 'activo'): ?> btn-danger <?php else: ?> btn-success <?php endif; ?> btn-delete" data-id="<?php echo e($gestion->id); ?>" data-estado="<?php echo e($gestion->estado); ?>">
    <i class="fas <?php if($gestion->estado == 'activo'): ?> fa-ban <?php else: ?> fa-eye <?php endif; ?>"></i>
</button><?php /**PATH C:\Users\anavarro\source\repos\icba\resources\views/gestiones/partials/_actions.blade.php ENDPATH**/ ?>