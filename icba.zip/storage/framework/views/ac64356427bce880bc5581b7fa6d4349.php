<?php $__env->startSection('subtitle', 'Principal'); ?>
<?php $__env->startSection('content_header_title', 'Principal'); ?>
<?php $__env->startSection('content_header_subtitle', 'Bienvenido'); ?>



<?php $__env->startSection('content_body'); ?>
    <p>Welcome to this admin panel.</p>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\anavarro\source\repos\icba\resources\views/welcome.blade.php ENDPATH**/ ?>