<?php echo csrf_field(); ?>
<?php if(isset($inscripcion)): ?>
    <?php echo method_field('PUT'); ?>
<?php endif; ?>

<div class="mb-3">
    <label for="alumno_id">Alumno</label>
    <select name="alumno_id" class="form-control" id="alumno_id">
        <?php $__empty_1 = true; $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($alumno->id); ?>" <?php echo e(old('alumno_id', $inscripcion->alumno_id ?? '') == $alumno->id ? 'selected' : ''); ?>>
                <?php echo e($alumno->nombre); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <option value="">No hay alumnos registrados</option>
        <?php endif; ?>
    </select>
</div>

<div class="mb-3">
    <label for="curso_gestion_id">Curso y Gestión</label>
    <select name="curso_gestion_id" class="form-control" id="curso_gestion_id">
        <?php $__empty_1 = true; $__currentLoopData = $cursosGestiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cursoGestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($cursoGestion->id); ?>" <?php echo e(old('curso_gestion_id', $inscripcion->curso_gestion_id ?? '') == $cursoGestion->id ? 'selected' : ''); ?>>
                <?php echo e($cursoGestion->nombre); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <option value="">No hay Cursos y Gestiones registrados</option>
        <?php endif; ?>
    </select>
</div>

<div class="mb-3">
    <label for="fecha_inscripcion">Fecha de Inscripción</label>
    <input type="date" name="fecha_inscripcion" id="fecha_inscripcion" class="form-control" value="<?php echo e(old('fecha_inscripcion', $inscripcion->fecha_inscripcion ?? '')); ?>">
</div>

<div class="mb-3">
    <label for="monto_total">Monto Total (Bs.)</label>
    <input type="number" name="monto_total" id="monto_total" class="form-control" value="<?php echo e(old('monto_total', $inscripcion->monto_total ?? '')); ?>">
</div>

<button type="submit" class="btn btn-primary">
    <i class="fas fa-save"></i> <?php echo e(isset($inscripcion) ? 'Actualizar' : 'Registrar'); ?>

</button>
<a href="<?php echo e(route('inscripciones.index')); ?>" class="btn btn-info">
    <i class="fas fa-arrow-left"></i> Volver
</a><?php /**PATH C:\Users\anavarro\source\repos\icba\resources\views/inscripciones/partials/_form.blade.php ENDPATH**/ ?>