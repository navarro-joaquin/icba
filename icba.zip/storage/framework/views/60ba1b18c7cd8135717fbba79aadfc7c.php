

<?php $__env->startSection('title', 'Profesores'); ?>
<?php $__env->startSection('content_header_title', 'Profesores'); ?>
<?php $__env->startSection('content_header_subtitle', 'Editar'); ?>

<?php $__env->startSection('content_body'); ?>

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Editar Profesor: <?php echo e($profesor->nombre); ?></h3>
            <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                </button>
            </div>
        </div>
        <div class="card-body">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <form action="<?php echo e(route('profesores.update', $profesor->id)); ?>" method="POST">
                <?php echo $__env->make('profesores.partials._form', ['profesor' => $profesor], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\anavarro\source\repos\icba\resources\views/profesores/edit.blade.php ENDPATH**/ ?>