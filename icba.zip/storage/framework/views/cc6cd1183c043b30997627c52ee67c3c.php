<a href="<?php echo e(route('pagos.edit', $pago)); ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>

<button class="btn btn-sm btn-danger btn-delete" data-id="<?php echo e($pago->id); ?>">
    <i class="fas fa-trash"></i>
</button>
<?php /**PATH C:\Users\anavarro\source\repos\icba\resources\views/pagos/partials/_actions.blade.php ENDPATH**/ ?>