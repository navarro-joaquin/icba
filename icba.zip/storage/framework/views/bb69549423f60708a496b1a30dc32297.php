<?php echo csrf_field(); ?>
<?php if(isset($alumno)): ?>
    <?php echo method_field('PUT'); ?>
<?php endif; ?>

<div class="mb-3">
    <label for="nombre">Nombre del Alumno</label>
    <input type="text" name="nombre" id="nombre" class="form-control" value="<?php echo e(old('nombre', $alumno->nombre ?? '')); ?>">
</div>

<div class="mb-3">
    <label for="fecha_nacimiento">Fecha de Nacimiento</label>
    <input type="date" name="fecha_nacimiento" id="fecha_nacimiento" class="form-control" value="<?php echo e(old('fecha_nacimiento', $alumno->fecha_nacimiento ?? '')); ?>">
</div>

<div class="mb-3">
    <label for="user_id">Usuario</label>
    <select name="user_id" class="form-control" id="user_id">
        <?php $__empty_1 = true; $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($usuario->id); ?>" <?php echo e(old('user_id', $alumno->user_id ?? '') == $usuario->id ? 'selected' : ''); ?>>
                <?php echo e($usuario->username); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <option value="">No hay usuarios registrados</option>
        <?php endif; ?>
    </select>
</div>

<button type="submit" class="btn btn-primary">
    <i class="fas fa-save"></i> <?php echo e(isset($alumno) ? 'Actualizar' : 'Registrar'); ?>

</button>
<a href="<?php echo e(route('alumnos.index')); ?>" class="btn btn-info">
    <i class="fas fa-arrow-left"></i> Volver
</a><?php /**PATH C:\Users\anavarro\source\repos\icba\resources\views/alumnos/partials/_form.blade.php ENDPATH**/ ?>