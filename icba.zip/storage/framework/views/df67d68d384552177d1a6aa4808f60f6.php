<a href="<?php echo e(route('cursos.edit', $curso)); ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>

<button class="btn btn-sm <?php if($curso->estado == 'activo'): ?> btn-danger <?php else: ?> btn-success <?php endif; ?> btn-delete" data-id="<?php echo e($curso->id); ?>" data-estado="<?php echo e($curso->estado); ?>">
    <i class="fas <?php if($curso->estado == 'activo'): ?> fa-ban <?php else: ?> fa-check <?php endif; ?>"></i>
</button><?php /**PATH C:\Users\anavarro\source\repos\icba\resources\views/cursos/partials/_actions.blade.php ENDPATH**/ ?>