<a href="<?php echo e(route('profesores.edit', $profesor)); ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>

<button class="btn btn-sm <?php if($profesor->estado == 'activo'): ?> btn-danger <?php else: ?> btn-success <?php endif; ?> btn-delete" data-id="<?php echo e($profesor->id); ?>" data-estado="<?php echo e($profesor->estado); ?>">
    <i class="fas <?php if($profesor->estado == 'activo'): ?> fa-ban <?php else: ?> fa-eye <?php endif; ?>"></i>
</button><?php /**PATH C:\Users\anavarro\source\repos\icba\resources\views/profesores/partials/_actions.blade.php ENDPATH**/ ?>