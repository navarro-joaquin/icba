<a href="<?php echo e(route('asistencias.edit', $asistencia)); ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>

<button class="btn btn-sm btn-danger btn-delete" data-id="<?php echo e($asistencia->id); ?>">
    <i class="fas fa-trash"></i>
</button>
<?php /**PATH C:\Users\anavarro\source\repos\icba\resources\views/asistencias/partials/_actions.blade.php ENDPATH**/ ?>