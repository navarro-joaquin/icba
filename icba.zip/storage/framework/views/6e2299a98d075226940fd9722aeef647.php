<?php echo csrf_field(); ?>
<?php if(isset($asistencia)): ?>
    <?php echo method_field('PUT'); ?>
<?php endif; ?>

<div class="mb-3">
    <label for="inscripcion_id">Inscripción:</label>
    <select name="inscripcion_id" id="inscripcion_id" class="form-control">
        <?php $__empty_1 = true; $__currentLoopData = $inscripciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inscripcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($inscripcion->id); ?>" <?php echo e(old('inscripcion_id', $asistencia->inscripcion_id ?? '') == $inscripcion->id ? 'selected' : ''); ?>>
                <?php echo e($inscripcion->alumno->nombre); ?> - (<?php echo e($inscripcion->curso_gestion->nombre); ?>)
            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <option value="">No hay inscripciones disponibles</option>
        <?php endif; ?>
    </select>
</div>

<div class="mb-3">
    <label for="clase_id">Clase:</label>
    <select name="clase_id" id="clase_id" class="form-control">
        <?php $__empty_1 = true; $__currentLoopData = $clases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($clase->id); ?>" <?php echo e(old('clase_id', $asistencia->clase_id ?? '') == $clase->id ? 'selected' : ''); ?>>
                N° <?php echo e($clase->numero_clase); ?> - (<?php echo e($clase->fecha_clase); ?>)
            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <option value="">No hay clases disponibles</option>
        <?php endif; ?>
    </select>
</div>

<div class="mb-3">
    <label for="presente">Presente:</label>
    <input
        type="checkbox"
        name="presente"
        id="presente"
        class="form-control"
        value="1"
        <?php if(old('presente', $asistencia->presente ?? 0)): echo 'checked'; endif; ?>
    >
</div>

<button type="submit" class="btn btn-primary">
    <i class="fas fa-save"></i> <?php echo e(isset($asistencia) ? 'Actualizar' : 'Registrar'); ?>

</button>
<a href="<?php echo e(route('asistencias.index')); ?>" class="btn btn-info">
    <i class="fas fa-arrow-left"></i> Volver
</a>
<?php /**PATH C:\Users\anavarro\source\repos\icba\resources\views/asistencias/partials/_form.blade.php ENDPATH**/ ?>