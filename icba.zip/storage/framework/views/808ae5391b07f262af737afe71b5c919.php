<?php echo csrf_field(); ?>
<?php if(isset($curso_gestion)): ?>
    <?php echo method_field('PUT'); ?>
<?php endif; ?>

<div class="mb-3">
    <label for="curso_id">Curso:</label>
    <select name="curso_id" id="curso_id" class="form-control">
        <?php $__empty_1 = true; $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($curso->id); ?>" <?php echo e(old('curso_id', $curso_gestion->curso_id ?? '') == $curso->id ? 'selected' : ''); ?>>
                <?php echo e($curso->nombre); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <option value="">No hay cursos disponibles</option>
        <?php endif; ?>
    </select>
</div>

<div class="mb-3">
    <label for="gestion_id">Gestiones:</label>
    <select name="gestion_id" id="gestion_id" class="form-control">
        <?php $__empty_1 = true; $__currentLoopData = $gestiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($gestion->id); ?>" <?php echo e(old('gestion_id', $curso_gestion->gestion_id ?? '') == $gestion->id ? 'selected' : ''); ?>>
                <?php echo e($gestion->nombre); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <option value="">No hay gestiones disponibles</option>
        <?php endif; ?>
    </select>
</div>

<button type="submit" class="btn btn-primary">
    <i class="fas fa-save"></i> <?php echo e(isset($alumno) ? 'Actualizar' : 'Registrar'); ?>

</button>
<a href="<?php echo e(route('alumnos.index')); ?>" class="btn btn-info">
    <i class="fas fa-arrow-left"></i> Volver
</a><?php /**PATH C:\Users\anavarro\source\repos\icba\resources\views/cursos-gestiones/partials/_form.blade.php ENDPATH**/ ?>