<footer class="main-footer">
    <?php echo $__env->yieldContent('footer'); ?>
</footer><?php /**PATH C:\Users\anavarro\source\repos\icba\vendor\jeroennoten\laravel-adminlte\src/../resources/views/partials/footer/footer.blade.php ENDPATH**/ ?>