<?php echo csrf_field(); ?>
<?php if(isset($profesor)): ?>
    <?php echo method_field('PUT'); ?>
<?php endif; ?>

<div class="mb-3">
    <label for="nombre">Nombre del Profesor</label>
    <input type="text" name="nombre" id="nombre" class="form-control" value="<?php echo e(old('nombre', $profesor->nombre ?? '')); ?>">
</div>

<div class="mb-3">
    <label for="especialidad">Especialidad</label>
    <input type="text" name="especialidad" id="especialidad" class="form-control" value="<?php echo e(old('especialidad', $profesor->especialidad ?? '')); ?>">
</div>

<div class="mb-3">
    <label for="user_id">Usuario</label>
    <select name="user_id" class="form-control" id="user_id">
        <?php $__empty_1 = true; $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($usuario->id); ?>" <?php echo e(old('user_id', $alumno->user_id ?? '') == $usuario->id ? 'selected' : ''); ?>>
                <?php echo e($usuario->username); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <option value="">No hay usuarios registrados</option>
        <?php endif; ?>
    </select>
</div>

<button type="submit" class="btn btn-primary">
    <i class="fas fa-save"></i> <?php echo e(isset($profesor) ? 'Actualizar' : 'Registrar'); ?>

</button>
<a href="<?php echo e(route('profesores.index')); ?>" class="btn btn-info">
    <i class="fas fa-arrow-left"></i> Volver
</a><?php /**PATH C:\Users\anavarro\source\repos\icba\resources\views/profesores/partials/_form.blade.php ENDPATH**/ ?>