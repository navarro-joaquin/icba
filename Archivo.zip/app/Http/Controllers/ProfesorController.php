<?php

namespace App\Http\Controllers;

use App\Models\Profesor;
use App\Models\User;
use Illuminate\Http\Request;

class ProfesorController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $usuarios = User::all();
        return view('profesores.index', compact('usuarios'));
    }

    public function list()
    {
        $profesores = Profesor::paginate(5);

        return response()->json([
            'html' => view('profesores.partials._table', compact('profesores'))->render()
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nombre' => 'required|string',
            'especialidad' => 'required|string',
            'user_id' => 'required|exists:users,id'
        ]);

        Profesor::create($validated);

        return response()->json([
            'success' => 'Profesor creado correctamente'
        ]);
    }

    /**
     * Display the specified resource.
     */
    public function show(Profesor $profesor)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Profesor $profesor)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Profesor $profesor)
    {
        $data = $request->only('nombre', 'especialidad', 'user_id');

        $profesor->update($data);

        return response()->json([
            'success' => 'Profesor actualizado correctamente'
        ]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Profesor $profesor)
    {
        $profesor->delete();

        return response()->json([
            'success' => 'Profesor eliminado correctamente'
        ]);
    }
}
