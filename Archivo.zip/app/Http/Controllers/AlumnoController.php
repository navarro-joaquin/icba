<?php

namespace App\Http\Controllers;

use App\Models\Alumno;
use App\Models\User;
use Illuminate\Http\Request;

class AlumnoController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $usuarios = User::all();
        return view('alumnos.index', compact('usuarios'));
    }

    public function list()
    {
        $alumnos = Alumno::paginate(5);
        return response()->json([
            'html' => view('alumnos.partials._table', compact('alumnos'))->render()
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nombre' => 'required|string',
            'fecha_nacimiento' => 'required|date',
            'user_id' => 'required|exists:users,id'
        ]);

        Alumno::create($validated);

        return response()->json([
            'success' => 'Alumno creado correctamente'
        ]);
    }

    /**
     * Display the specified resource.
     */
    public function show(Alumno $alumno)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Alumno $alumno)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Alumno $alumno)
    {
        $data = $request->only('nombre', 'fecha_nacimiento', 'user_id');

        $alumno->update($data);

        return response()->json([
            'success' => 'Alumno actualizado correctamente'
        ]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Alumno $alumno)
    {
        $alumno->delete();

        return response()->json([
            'success' => 'Alumno eliminado correctamente'
        ]);
    }
}
