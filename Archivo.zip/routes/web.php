<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\UsuarioController;
use App\Http\Controllers\AlumnoController;
use App\Http\Controllers\ProfesorController;

Auth::routes();

Route::get('/', [HomeController::class, 'index'])->name('home');

// Usuarios
Route::get('usuarios', [UsuarioController::class, 'index'])->name('usuarios.index');
Route::get('usuarios/list', [UsuarioController::class, 'list'])->name('usuarios.list');
Route::post('usuarios', [UsuarioController::class, 'store'])->name('usuarios.store');
Route::put('usuarios/{usuario}', [UsuarioController::class, 'update'])->name('usuarios.update');
Route::delete('usuarios/{usuario}', [UsuarioController::class, 'destroy'])->name('usuarios.destroy');

// Alumnos
Route::get('alumnos', [AlumnoController::class, 'index'])->name('alumnos.index');
Route::get('alumnos/list', [AlumnoController::class, 'list'])->name('alumnos.list');
Route::post('alumnos', [AlumnoController::class, 'store'])->name('alumnos.store');
Route::put('alumnos/{alumno}', [AlumnoController::class, 'update'])->name('alumnos.update');
Route::delete('alumnos/{alumno}', [AlumnoController::class, 'destroy'])->name('alumnos.destroy');

// Profesores
Route::get('profesores', [ProfesorController::class, 'index'])->name('profesores.index');
Route::get('profesores/list', [ProfesorController::class, 'list'])->name('profesores.list');
Route::post('profesores', [ProfesorController::class, 'store'])->name('profesores.store');
Route::put('profesores/{profesor}', [ProfesorController::class, 'update'])->name('profesores.update');
Route::delete('profesores/{profesor}', [ProfesorController::class, 'destroy'])->name('profesores.destroy');


