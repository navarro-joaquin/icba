<div class="modal fade" id="modalCrear" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <form id="formCrear">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Crear profesor</h5>
                </div>
                <div class="modal-body">
                    <?php echo $__env->make('profesores.partials._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">
                        <i class="fas fa-ban"></i> Cancelar
                    </button>
                    <button class="btn btn-primary" type="submit">
                        <i class="fas fa-save"></i> Guardar
                    </button>
                </div>
            </div>
        </form>
    </div>
</div><?php /**PATH /Users/alvaro/Code/icba/resources/views/alumnos/partials/_modalCrear.blade.php ENDPATH**/ ?>