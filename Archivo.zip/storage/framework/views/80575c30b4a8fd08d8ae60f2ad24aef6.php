<div class="mb-3">
    <label for="nombre">Nombre del Profesor</label>
    <input type="text" name="nombre" id="nombre" class="form-control" required>
</div>

<div class="mb-3">
    <label for="especialidad">Especialidad</label>
    <input type="text" name="especialidad" id="especialidad" class="form-control" required>
</div>

<div class="mb-3">
    <label for="user_id">Usuario</label>
    <select name="user_id" id="user_id" class="form-control" required>
        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($usuario->id); ?>">
                <?php echo e($usuario->username); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div><?php /**PATH /Users/alvaro/Code/icba/resources/views/profesores/partials/_form.blade.php ENDPATH**/ ?>