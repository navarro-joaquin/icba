<table class="table table-bordered">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre de Usuario</th>
            <th>Correo Electrónico</th>
            <th>Rol</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($usuario->id); ?></td>
            <td><?php echo e($usuario->username); ?></td>
            <td><?php echo e($usuario->email); ?></td>
            <td><?php echo e($usuario->role); ?></td>
            <td>
                <button class="btn btn-warning btn-sm btn-editar" data-user='<?php echo json_encode($usuario, 15, 512) ?>'>
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-danger btn-sm btn-eliminar" data-id="<?php echo e($usuario->id); ?>">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="d-flex justify-content-center mt-3">
    <?php echo $usuarios->links(); ?>

</div><?php /**PATH /Users/alvaro/Code/icba/resources/views/usuarios/partials/_table.blade.php ENDPATH**/ ?>