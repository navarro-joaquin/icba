<button class="btn btn-warning btn-sm btn-editar" data-user="<?php echo json_encode($usuario, 15, 512) ?>">
    <i class="fas fa-edit"></i>
</button>
<button class="btn btn-danger btn-sm btn-eliminar" data-id="<?php echo e($usuario->id); ?>">
    <i class="fas fa-trash"></i>
</button><?php /**PATH /Users/alvaro/Code/icba/resources/views/usuarios/partials/_actions.blade.php ENDPATH**/ ?>