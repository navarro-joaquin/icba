<table class="table table-bordered">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Fecha de Nacimiento</th>
            <th>Usuario</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($alumno->id); ?></td>
            <td><?php echo e($alumno->nombre); ?></td>
            <td><?php echo e($alumno->fecha_nacimiento); ?></td>
            <td><?php echo e($alumno->user->username); ?></td>
            <td>
                <button class="btn btn-warning btn-sm btn-editar" data-alumno='<?php echo json_encode($alumno, 15, 512) ?>'>
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-danger btn-sm btn-eliminar" data-id="<?php echo e($alumno->id); ?>">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="d-flex justify-content-center mt-3">
    <?php echo $alumnos->links(); ?>

</div><?php /**PATH /Users/alvaro/Code/icba/resources/views/alumnos/partials/_table.blade.php ENDPATH**/ ?>