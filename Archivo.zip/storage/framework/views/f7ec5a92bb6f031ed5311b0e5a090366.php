<?php $__env->startSection('title', 'Alumnos'); ?>
<?php $__env->startSection('content_header_title', 'Alumnos'); ?>
<?php $__env->startSection('content_header_subtitle', 'Listado'); ?>

<?php $__env->startSection('content_body'); ?>

    <div class="card">
        <div class="card-header d-flex align-items-center">
            <div class="flex-grow-1">
                <h3 class="card-title mb-0">Listado de Alumnos</h3>
            </div>
            <button class="btn btn-success" data-toggle="modal" data-target="#modalCrear">
                <i class="fas fa-user-plus"></i> Nuevo Alumno
            </button>
        </div>
        <div class="card-body">
            <div id="alert-container"></div>
            <div id="table-container">
                <?php echo $__env->make('alumnos.partials._table', ['alumnos' => \App\Models\Alumno::paginate(5)], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>
    </div>

    <?php echo $__env->make('alumnos.partials._modalCrear', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('alumnos.partials._modalEditar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    function cargarTabla(page = 1) {
        $.get(`<?php echo e(route('alumnos.list')); ?>?page=${page}`, function(data) {
            $('#table-container').html(data.html)
        })
    }

    $(document).on('click', '.pagination a', function(e) {
        e.preventDefault()
        const page = $(this).attr('href').split('page=')[1]
        cargarTabla(page)
    })

    // Crear alumno
    $('#formCrear').submit(function(e) {
        e.preventDefault()
        $.ajax({
            url: '<?php echo e(route('alumnos.store')); ?>',
            method: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                $('#modalCrear').modal('hide')
                Swal.fire('Exito', response.success, 'success')
                $('#formCrear')[0].reset()
                cargarTabla()
            },
            error: function(xhr) {
                if (xhr.status === 422) {
                    let errores = xhr.responseJSON.errores
                    let mensaje = Object.values(errores).map(e => e.join('<br>')).join('<hr>')
                    Swal.fire('Errores de validación', mensaje, 'error')
                } else {
                    Swal.fire('Error', 'Ocurrió un error al crear', 'error')
                }
            }
        })
    })

    // Cargar valores en el modal de Editar
    $(document).on('click', '.btn-editar', function() {
        const alumno = $(this).data('alumno')
        $('#formEditar input[name="id"]').val(alumno.id)
        $('#formEditar input[name="nombre"]').val(alumno.nombre)
        $('#formEditar input[name="fecha_nacimiento"]').val(alumno.fecha_nacimiento)
        $('#formEditar select[name="user_id"]').val(alumno.user_id)
        $('#modalEditar').modal('show')
    })

    // Editar usuario
    $('#formEditar').submit(function(e) {
        e.preventDefault()
        const id = $('#formEditar input[name="id"]').val()
        $.ajax({
            url: '<?php echo e(route('alumnos.update', ':id')); ?>'.replace(':id', id),
            method: 'PUT',
            data: $(this).serialize(),
            success: function(response) {
                $('#modalEditar').modal('hide')
                Swal.fire('Exito', response.success, 'success')
                $('#formEditar')[0].reset()
                cargarTabla()
            },
            error: function(xhr) {
                if (xhr.status === 422) {
                    let errores = xhr.responseJSON.errors
                    let mensaje = Object.values(errores).map(e => e.join('<br>')).join('<hr>')
                    Swal.fire('Errores de validación', mensaje, 'error')
                } else {
                    Swal.fire('Error', 'Ocurrió un error al editar', 'error')
                }
            }
        })
    })

    // Eliminar un alumno
    $(document).on('click', '.btn-eliminar', function() {
        const id = $(this).data('id')
        const url = '<?php echo e(route('alumnos.destroy', ':id')); ?>'.replace(':id', id)
        Swal.fire({
            title: '¿Desea eliminar el alumno?',
            text: 'Esta acción no se puede deshacer',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: url,
                    type: 'DELETE',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>',
                    },
                    success: function(response) {
                        Swal.fire('Eliminado', response.success, 'success')
                        cargarTabla()
                    }
                })
            }
        })
    })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/alvaro/Code/icba/resources/views/alumnos/index.blade.php ENDPATH**/ ?>