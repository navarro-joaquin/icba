<table class="table table-bordered">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Especialidad</th>
            <th>Usuario</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $profesores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profesor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($profesor->id); ?></td>
            <td><?php echo e($profesor->nombre); ?></td>
            <td><?php echo e($profesor->especialidad); ?></td>
            <td><?php echo e($profesor->user->username); ?></td>
            <td>
                <button class="btn btn-warning btn-sm btn-editar" data-profesor='<?php echo json_encode($profesor, 15, 512) ?>'>
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-danger btn-sm btn-eliminar" data-id="<?php echo e($profesor->id); ?>">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH /Users/alvaro/Code/icba/resources/views/profesores/partials/_table.blade.php ENDPATH**/ ?>