<?php $__env->startSection('title'); ?>
  <?php echo e('ICBA'); ?>

  <?php if (! empty(trim($__env->yieldContent('subtitle')))): ?> | <?php echo $__env->yieldContent('subtitle'); ?> <?php endif; ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content_header'); ?>
  <?php if (! empty(trim($__env->yieldContent('content_header_title')))): ?>
    <h1 class="text-muted">
      <?php echo $__env->yieldContent('content_header_title'); ?>

      <?php if (! empty(trim($__env->yieldContent('content_header_subtitle')))): ?>
        <small class="text-dark">
          <i class="fa fa-xs fa-angle-right text-muted"></i>
          <?php echo $__env->yieldContent('content_header_subtitle'); ?>
        </small>
      <?php endif; ?>
    </h1>
  <?php endif; ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
  <?php echo $__env->yieldContent('content_body'); ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('footer'); ?>
  <div class="float-right">
    Version: <?php echo e(config('app.version', '1.0.0')); ?>

  </div>

  <strong>
    <a href="<?php echo e(config('app.company_url', 'https://nvrrcors.pro')); ?>">
      <?php echo e(config('app.company_name', 'NvrrCors')); ?>

    </a>
  </strong>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php if(session('success')): ?>
  <script>
    Swal.fire({
      icon: 'success',
      title: '<?php echo e(session('success')); ?>',
      showConfirmButton: false,
      timer: 2000
    })  
  </script>
<?php endif; ?>
<?php $__env->stopPush(); ?>



<?php $__env->startPush('css'); ?>
  <style type="text/css">
    
  </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/alvaro/Code/icba/resources/views/layouts/app.blade.php ENDPATH**/ ?>