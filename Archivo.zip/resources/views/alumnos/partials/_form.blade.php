<div class="mb-3">
    <label for="nombre">Nombre del Alumno</label>
    <input type="text" name="nombre" id="nombre" class="form-control" required>
</div>

<div class="mb-3">
    <label for="fecha_nacimiento">Fecha de Nacimiento</label>
    <input type="date" name="fecha_nacimiento" id="fecha_nacimiento" class="form-control" required>
</div>

<div class="mb-3">
    <label for="user_id">Usuario</label>
    <select name="user_id" id="user_id" class="form-control" required>
        @foreach ($usuarios as $usuario)
            <option value="{{ $usuario->id }}">
                {{ $usuario->username }}
            </option>
        @endforeach
    </select>
</div>
