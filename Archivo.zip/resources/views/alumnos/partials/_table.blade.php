<table class="table table-bordered">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Fecha de Nacimiento</th>
            <th>Usuario</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        @foreach($alumnos as $alumno)
        <tr>
            <td>{{ $alumno->id }}</td>
            <td>{{ $alumno->nombre }}</td>
            <td>{{ $alumno->fecha_nacimiento }}</td>
            <td>{{ $alumno->user->username }}</td>
            <td>
                <button class="btn btn-warning btn-sm btn-editar" data-alumno='@json($alumno)'>
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-danger btn-sm btn-eliminar" data-id="{{ $alumno->id }}">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
<div class="d-flex justify-content-center mt-3">
    {!! $alumnos->links() !!}
</div>