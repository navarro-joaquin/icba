@extends('layouts.app')

{{-- Customize layout sections --}}

@section('subtitle', 'Principal')
@section('content_header_title', 'Principal')
@section('content_header_subtitle', 'Bienvenido')

{{-- Content body: main page content --}}

@section('content_body')
    <p>Welcome to this admin panel.</p>
@stop


