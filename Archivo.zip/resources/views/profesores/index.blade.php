@extends('layouts.app')

@section('title', 'Profesores')
@section('content_header_title', 'Profesores')
@section('content_header_subtitle', 'Listado')

@section('content_body')

    <div class="card">
        <div class="card-header d-flex align-items-center">
            <div class="flex-grow-1">
                <h3 class="card-title mb-0">Listado de Profesores</h3>
            </div>
            <button class="btn btn-success" data-toggle="modal" data-target="#modalCrear">
                <i class="fas fa-user-plus"></i> Nuevo Profesor
            </button>
        </div>
        <div class="card-body">
            <div id="alert-container"></div>
            <div id="table-container">
                @include('profesores.partials._table', ['profesores' => \App\Models\Profesor::paginate(5)])
            </div>
        </div>
    </div>

    @include('alumnos.partials._modalCrear')
    @include('alumnos.partials._modalEditar')

@stop

@push('js')
<script>
    function cargarTabla(page = 1) {
        $.get(`{{ route('profesores.list') }}?page=${page}`, function(data) {
            $('#table-container').html(data.html)
        })
    }

    $(document).on('click', '.pagination a', function(e) {
        e.preventDefault()
        const page = $(this).attr('href').split('page=')[1]
        cargarTabla(page)
    })

    // Crear profesor
    $('#formCrear').submit(function(e) {
        e.preventDefault()
        $.ajax({
            url: '{{ route('profesores.store') }}',
            method: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                $('#modalCrear').modal('hide')
                Swal.fire('Exito', response.success, 'success')
                $('#formCrear')[0].reset()
                cargarTabla()
            },
            error: function(xhr) {
                if (xhr.status === 422) {
                    let errores = xhr.responseJSON.errors
                    let mensaje = Object.values(errores).map(e => e.join('<br>')).join('<hr>')
                    Swal.fire('Errores de validación', mensaje, 'error')
                } else {
                    Swal.fire('Error', 'Ocurrido un error al crear', 'error')
                }
            }
        })
    })

    // Cargar valores en el modal de Editar
    $(document).on('click', '.btn-editar', function() {
        const profesor = $(this).data('profesor')
        $('#formEditar input[name="id"]').val(profesor.id)
        $('#formEditar input[name="nombre"]').val(profesor.nombre)
        $('#formEditar input[name="especialidad"]').val(profesor.especialidad)
        $('#formEditar select[name="user_id"]').val(profesor.user_id)
        $('#modalEditar').modal('show')
    })

    // Editar profesor
    $('#formEditar').submit(function(e) {
        e.preventDefault()
        const id = $('#formEditar input[name="id"]').val()
        $.ajax({
            url: '{{ route('profesores.update', ':id') }}'.replace(':id', id),
            method: 'PUT',
            data: $(this).serialize(),
            success: function(response) {
                $('#modalEditar').modal('hide')
                Swal.fire('Exito', response.success, 'success')
                $('#formEditar')[0].reset()
                cargarTabla()
            },
            error: function(xhr) {
                if (xhr.status === 422) {
                    let errores = xhr.responseJSON.errors
                    let mensaje = Object.values(errores).map(e => e.join('<br>')).join('<hr>')
                    Swal.fire('Errores de validación', mensaje, 'error')
                } else {
                    Swal.fire('Error', 'Ocurrió un error al editar', 'error')
                }
            }
        })
    })

    // Eliminar un profesor
    $(document).on('click', '.btn-eliminar', function() {
        const id = $(this).data('id')
        const url = '{{ route('profesores.destroy', ':id') }}'.replace(':id', id)
        Swal.fire({
            title: '¿Desea eliminar el profesor?',
            text: 'Esta acción no se puede deshacer',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: url,
                    type: 'DELETE',
                    data: {
                        _token: '{{ csrf_token() }}',
                    },
                    success: function(response) {
                        Swal.fire('Eliminado', response.success, 'success')
                        cargarTabla()
                    }
                })
            }
        })
    })
</script>
@endpush