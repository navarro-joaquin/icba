<table class="table table-bordered">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Especialidad</th>
            <th>Usuario</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        @foreach($profesores as $profesor)
        <tr>
            <td>{{ $profesor->id }}</td>
            <td>{{ $profesor->nombre }}</td>
            <td>{{ $profesor->especialidad }}</td>
            <td>{{ $profesor->user->username }}</td>
            <td>
                <button class="btn btn-warning btn-sm btn-editar" data-profesor='@json($profesor)'>
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-danger btn-sm btn-eliminar" data-id="{{ $profesor->id }}">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>