<div class="mb-3">
    <label for="username">Nombre de Usuario</label>
    <input type="text" name="username" id="username" class="form-control" required>
</div>
<div class="mb-3">
    <label for="email">Correo Electrónico</label>
    <input type="text" name="email" id="email" class="form-control" required>
</div>
<div class="mb-3">
    <label for="role">Rol</label>
    <select name="role" class="form-control" id="role" required>
        <option value="">--Selecciona una opción--</option>
        <option value="admin">Administrador</option>
        <option value="alumno">Alumno</option>
        <option value="profesor">Profesor</option>
        <option value="gestor">Gestor</option>
    </select>
</div>
<div class="mb-3">
    <label for="password">Contraseña</label>
    <input type="password" name="password" id="password" class="form-control">
</div>