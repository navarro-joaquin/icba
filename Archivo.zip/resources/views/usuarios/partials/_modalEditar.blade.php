<div class="modal fade" id="modalEditar" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <form id="formEditar">
            @csrf
            @method('PUT')
            <input type="hidden" name="id">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Editar usuario</h5>
                </div>
                <div class="modal-body">  
                    @include('usuarios.partials._form')
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">
                        <i class="fas fa-ban"></i> Cancelar
                    </button>
                    <button class="btn btn-primary" type="submit">
                        <i class="fas fa-save"></i> Guardar
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>